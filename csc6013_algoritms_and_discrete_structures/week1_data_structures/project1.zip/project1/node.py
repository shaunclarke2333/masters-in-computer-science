class Node:
    def __init__(self, d):
        self.Data = d
        self.Next = None